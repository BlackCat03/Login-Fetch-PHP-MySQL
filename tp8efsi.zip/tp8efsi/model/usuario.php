<?php
final class usuario {
    public $id; 
    public $nombre; 
    public $apellido; 
    public $email;
    public $clave; 
} 
?>